package com.example.cookvoice.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cookvoice.data.cleanAiText
import com.example.cookvoice.data.parseAiRecipe
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.launch

@Composable
fun OnlineScreen(
    generativeModel: GenerativeModel,
    onPlayVoice: (String) -> Unit,
    onStartVoice: (((String) -> Unit) -> Unit)
) {
    var ingredients by remember { mutableStateOf("") }
    var rawAiResponse by remember { mutableStateOf("") }
    var weeklyMenuPlan by remember { mutableStateOf("") }
    var chefTip by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    fun processAndGenerateRecipe(inputIngredients: String) {
        val cleanItems = inputIngredients.split(",").map { it.trim() }.filter { it.isNotEmpty() }

        if (cleanItems.size < 3) {
            Toast.makeText(context, "Por favor ingresa al menos 3 ingredientes para una mejor recomendación", Toast.LENGTH_LONG).show()
            return
        }

        isLoading = true
        rawAiResponse = ""
        weeklyMenuPlan = ""
        chefTip = ""

        scope.launch {
            try {
                val validationPrompt = "Analiza el siguiente texto ingresado por un usuario: '$inputIngredients'. Responde estrictamente con la palabra 'VALIDO' si los términos corresponden a alimentos, frutas, verduras, carnes, lácteos, dulces o ingredientes de cocina comestibles. Responde estrictamente con la palabra 'INVALIDO' si el texto contiene objetos, cosas que no se comen, groserías o texto sin sentido."
                val validationResponse = generativeModel.generateContent(validationPrompt).text?.trim()?.uppercase() ?: ""

                if (validationResponse.contains("INVALIDO")) {
                    Toast.makeText(context, "Error: Por favor ingresa únicamente alimentos o ingredientes comestibles válidos.", Toast.LENGTH_LONG).show()
                    isLoading = false
                    return@launch
                }

                val prompt = """
                    Actúa como un Chef Maestro experto en la gastronomía tradicional de Nariño, Colombia.
                    El usuario ingresó los siguientes ingredientes: '$inputIngredients'.
                    
                    Por favor genera la respuesta dividida exactamente con estas etiquetas para que se pueda parsear correctamente:
                    
                    TÍTULO: [Nombre real y específico del plato típico nariñense adaptado]
                    
                    INGREDIENTES: [Lista exacta con gramos, mililitros o unidades precisas combinando lo del usuario con condimentos andinos]
                    
                    PREPARACIÓN: [Tiempo total y pasos numerados detallados con rigor técnico, fuegos y tiempos exactos]
                    
                    MENÚ:
                    LUNES:
- Plato Fuerte: [Nombre y preparación detallada paso a paso con gramos y tiempos]
- Bebida: [Nombre y preparación breve]
- Postre: [Nombre y preparación breve]

                    MIÉRCOLES:
- Plato Fuerte: [Nombre y preparación detallada paso a paso con gramos y tiempos]
- Bebida: [Nombre y preparación breve]
- Postre: [Nombre y preparación breve]

                    VIERNES:
- Plato Fuerte: [Nombre y preparación detallada paso a paso con gramos y tiempos]
- Bebida: [Nombre y preparación breve]
- Postre: [Nombre y preparación breve]

                    SECRETO_CHEF: [Un consejo de cocina único, profesional y creativo específico y exclusivo sobre cómo tratar o combinar los ingredientes '$inputIngredients' al estilo de la cocina nariñense]
                """.trimIndent()

                val response = generativeModel.generateContent(prompt)
                val fullText = response.text ?: throw Exception("Respuesta vacía del modelo")

                var mainRecipePart = fullText
                var menuPart = ""
                var tipPart = "El secreto del chef: Cuida muy bien las temperaturas y usa siempre condimentos frescos para resaltar la sazón tradicional."

                if (fullText.contains("MENÚ:")) {
                    val splitMenu = fullText.split("MENÚ:")
                    mainRecipePart = splitMenu[0]
                    val restOfText = splitMenu[1]

                    if (restOfText.contains("SECRETO_CHEF:")) {
                        val splitTip = restOfText.split("SECRETO_CHEF:")
                        menuPart = splitTip[0]
                        tipPart = splitTip[1]
                    } else {
                        menuPart = restOfText
                    }
                } else if (fullText.contains("SECRETO_CHEF:")) {
                    val splitTip = fullText.split("SECRETO_CHEF:")
                    mainRecipePart = splitTip[0]
                    tipPart = splitTip[1]
                }

                rawAiResponse = mainRecipePart.trim()
                weeklyMenuPlan = cleanAiText(menuPart.trim())
                chefTip = cleanAiText(tipPart.trim())

            } catch (e: Exception) {
                Toast.makeText(context, "Error de cuota o red: ${e.localizedMessage ?: "Límite excedido"}", Toast.LENGTH_LONG).show()
            } finally {
                isLoading = false
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFE0F7FA),
                        Color(0xFFE8EAF6),
                        Color(0xFFEDE7F6)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF006064))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Chef IA Nariñense", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color(0xFF00363A))
            }
            Text("Ingresa tus ingredientes. La IA armará una receta exacta, menú detallado y consejo único del chef.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF004D40))
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = ingredients,
                    onValueChange = { ingredients = it },
                    label = { Text("Ej: Papa, queso, choclo, carne...") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    leadingIcon = { Icon(Icons.Default.Kitchen, contentDescription = null, tint = Color(0xFF006064)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF006064),
                        unfocusedBorderColor = Color(0xFFB2DFDB),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White.copy(alpha = 0.8f)
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        onStartVoice { spokenText ->
                            val formattedVoiceInput = spokenText.split(Regex("\\s+")).joinToString(", ")
                            ingredients = if (ingredients.isBlank()) {
                                formattedVoiceInput
                            } else {
                                "$ingredients, $formattedVoiceInput"
                            }
                            processAndGenerateRecipe(ingredients)
                        }
                    },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF006064))
                ) {
                    Icon(Icons.Default.Mic, contentDescription = "Dictar ingredientes", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = { processAndGenerateRecipe(ingredients) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006064)),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("Creando receta detallada y menú...")
                } else {
                    Icon(Icons.Default.Restaurant, contentDescription = "Generar")
                    Spacer(Modifier.width(8.dp))
                    Text("Generar Receta, Menú y Consejo del Chef")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (rawAiResponse.isNotEmpty()) {
                val parsed = parseAiRecipe(rawAiResponse)

                Column(modifier = Modifier.fillMaxWidth()) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).wrapContentHeight(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFB2EBF2)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp).fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.RestaurantMenu, contentDescription = null, tint = Color(0xFF006064), modifier = Modifier.size(32.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.wrapContentHeight()) {
                                    Text("Plato Nariñense Recomendado", style = MaterialTheme.typography.labelMedium, color = Color(0xFF006064), fontWeight = FontWeight.Bold)
                                    Text(parsed.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF00251A))
                                }
                            }
                            IconButton(
                                onClick = { onPlayVoice("Plato recomendado: ${parsed.title}") },
                                modifier = Modifier.background(Color(0xFF006064).copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                            ) {
                                Icon(Icons.Default.VolumeUp, contentDescription = "Escuchar título", tint = Color(0xFF006064))
                            }
                        }
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).wrapContentHeight(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp).wrapContentHeight()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Kitchen, contentDescription = null, tint = Color(0xFF006064))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Ingredientes Exactos (Gramos y Medidas)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF00363A))
                                }
                                IconButton(
                                    onClick = { onPlayVoice("Ingredientes exactos: ${parsed.ingredients}") },
                                    modifier = Modifier.background(Color(0xFF006064).copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "Escuchar ingredientes", tint = Color(0xFF006064))
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(parsed.ingredients, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF212121))
                        }
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).wrapContentHeight(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp).wrapContentHeight()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color(0xFF006064))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Preparación Paso a Paso con Tiempos", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF00363A))
                                }
                                IconButton(
                                    onClick = { onPlayVoice("Preparación detallada: ${parsed.preparation}") },
                                    modifier = Modifier.background(Color(0xFF006064).copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                ) {
                                    Icon(Icons.Default.VolumeUp, contentDescription = "Escuchar preparación", tint = Color(0xFF006064))
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = parsed.preparation,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF212121),
                                lineHeight = 22.sp
                            )
                        }
                    }

                    if (weeklyMenuPlan.isNotEmpty()) {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).wrapContentHeight(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2F1)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp).wrapContentHeight()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFF00695C), modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text("Menú Semanal Detallado (3 Días)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF00695C))
                                    }
                                    IconButton(
                                        onClick = { onPlayVoice("Menú semanal detallado: $weeklyMenuPlan") },
                                        modifier = Modifier.background(Color(0xFF00695C).copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                    ) {
                                        Icon(Icons.Default.VolumeUp, contentDescription = "Escuchar menú", tint = Color(0xFF00695C))
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = weeklyMenuPlan,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF004D40),
                                    lineHeight = 22.sp
                                )
                            }
                        }
                    }

                    if (chefTip.isNotEmpty()) {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp).wrapContentHeight(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDE7)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp).wrapContentHeight()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(Icons.Default.Lightbulb, contentDescription = null, tint = Color(0xFFF57F17), modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(8.dp))
                                        Text("Secreto del Chef para tus Ingredientes", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFFF57F17))
                                    }
                                    IconButton(
                                        onClick = { onPlayVoice("Secreto del chef: $chefTip") },
                                        modifier = Modifier.background(Color(0xFFF57F17).copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                    ) {
                                        Icon(Icons.Default.VolumeUp, contentDescription = "Escuchar secreto", tint = Color(0xFFF57F17))
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(chefTip, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF5D4037))
                            }
                        }
                    }

                    Button(
                        onClick = { onPlayVoice("Plato recomendado: ${parsed.title}. Ingredientes: ${parsed.ingredients}. Preparación: ${parsed.preparation}. Menú: $weeklyMenuPlan. Secreto del chef: $chefTip") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006064))
                    ) {
                        Icon(Icons.Default.VolumeUp, contentDescription = "Escuchar todo")
                        Spacer(Modifier.width(8.dp))
                        Text("Escuchar Todo el Contenido Generado")
                    }
                }
            }
        }
    }
}