package com.example.cookvoice.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cookvoice.data.Recipe
import com.example.cookvoice.data.narinoRecipes

@Composable
fun OfflineScreen(onPlayVoice: (String) -> Unit, onStartVoice: (((String) -> Unit) -> Unit)) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Todos") }

    val categories = remember {
        listOf("Todos") + narinoRecipes.map { it.category }.distinct()
    }

    val filteredRecipes = remember(searchQuery, selectedCategory) {
        narinoRecipes.filter { recipe ->
            val matchesSearch = searchQuery.isBlank() ||
                    recipe.name.contains(searchQuery, ignoreCase = true) ||
                    recipe.category.contains(searchQuery, ignoreCase = true)

            val matchesCategory = selectedCategory == "Todos" ||
                    recipe.category.equals(selectedCategory, ignoreCase = true)

            matchesSearch && matchesCategory
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFFAED),
                        Color(0xFFFFF3D6),
                        Color(0xFFFFE0B2)
                    )
                )
            )
    ) {
        LazyColumn(contentPadding = PaddingValues(16.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color(0xFFB71C1C))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Recetario Tradicional de Nariño", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color(0xFF3E2723))
                }
                Text("Busca por nombre, filtra por categorías o usa la voz.", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF5D4037))
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Buscar plato o dictar nombre...") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFFB71C1C)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFB71C1C),
                            unfocusedBorderColor = Color(0xFFD7CCC8),
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White.copy(alpha = 0.8f)
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            onStartVoice { spokenText ->
                                searchQuery = spokenText
                            }
                        },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFFB71C1C))
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Buscar por voz", tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Categorías:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color(0xFF3E2723))
                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(categories) { category ->
                        val isSelected = selectedCategory == category
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFB71C1C),
                                selectedLabelColor = Color.White,
                                containerColor = Color.White,
                                labelColor = Color(0xFF5D4037)
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                borderColor = if (isSelected) Color(0xFFB71C1C) else Color(0xFFD7CCC8),
                                selectedBorderColor = Color(0xFFB71C1C),
                                enabled = true,
                                selected = isSelected
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            if (filteredRecipes.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No se encontró ningún plato para esta selección", style = MaterialTheme.typography.bodyLarge, color = Color(0xFF5D4037))
                    }
                }
            } else {
                items(filteredRecipes) { recipe ->
                    RecipeCard(recipe, onPlayVoice)
                }
            }
        }
    }
}

@Composable
fun RecipeCard(recipe: Recipe, onPlayVoice: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    val difficultyColor = when (recipe.difficulty) {
        "Fácil" -> Color(0xFF2E7D32)
        "Media" -> Color(0xFFEF6C00)
        else -> Color(0xFFC62828)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .wrapContentHeight(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
            ) {
                Image(
                    painter = painterResource(id = recipe.imageRes),
                    contentDescription = recipe.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFE65100),
                    modifier = Modifier
                        .padding(12.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text(
                        text = recipe.category,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                IconButton(
                    onClick = { expanded = !expanded },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .size(40.dp)
                        .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(20.dp))
                ) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expandir",
                        tint = Color(0xFFB71C1C)
                    )
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = recipe.name,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF212121)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF757575))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(recipe.prepTime, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF757575), fontWeight = FontWeight.Medium)

                        Spacer(modifier = Modifier.width(12.dp))

                        Icon(Icons.Default.LocalFireDepartment, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFFE65100))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(recipe.calories, style = MaterialTheme.typography.bodyMedium, color = Color(0xFFE65100), fontWeight = FontWeight.Bold)
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(difficultyColor.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = recipe.difficulty,
                            color = difficultyColor,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                AnimatedVisibility(visible = expanded, enter = fadeIn() + expandVertically()) {
                    Column(Modifier.padding(top = 16.dp)) {
                        HorizontalDivider(color = Color(0xFFE0E0E0))
                        Spacer(Modifier.height(14.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Kitchen, contentDescription = null, tint = Color(0xFFB71C1C), modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Ingredientes:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF3E2723))
                        }
                        Spacer(Modifier.height(8.dp))

                        recipe.ingredients.forEach { ingredient ->
                            Column(modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(Color(0xFFE65100))
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = ingredient,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF424242),
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                HorizontalDivider(color = Color(0xFFF5F5F5), thickness = 1.dp)
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color(0xFFB71C1C), modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Preparación Paso a Paso:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFF3E2723))
                        }
                        Spacer(Modifier.height(8.dp))

                        Text(
                            text = recipe.preparation,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF424242),
                            lineHeight = 22.sp,
                            modifier = Modifier.padding(start = 16.dp)
                        )

                        Spacer(Modifier.height(20.dp))
                        Button(
                            onClick = { onPlayVoice("${recipe.name}. Tiempo de preparación: ${recipe.prepTime}. Calorías aproximadas: ${recipe.calories}. Ingredientes: ${recipe.ingredients.joinToString(", ")}. Preparación: ${recipe.preparation}") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
                        ) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Escuchar")
                            Spacer(Modifier.width(8.dp))
                            Text("Escuchar Receta Completa")
                        }
                    }
                }
            }
        }
    }
}