package com.example.cookvoice

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.cookvoice.ui.screens.OfflineScreen
import com.example.cookvoice.ui.screens.OnlineScreen
import com.example.cookvoice.ui.screens.SplashScreen
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.delay
import java.util.*

class MainActivity : ComponentActivity() {
    private var speechResultCallback: ((String) -> Unit)? = null

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!results.isNullOrEmpty()) {
                speechResultCallback?.invoke(results[0])
            }
        }
    }

    fun startVoiceInput(onResult: (String) -> Unit) {
        speechResultCallback = onResult
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla claro para buscar o dictar ingredientes...")
        }
        try {
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "El reconocimiento de voz no está disponible en este dispositivo", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFFB71C1C),
                    primaryContainer = Color(0xFFFFCDD2),
                    secondary = Color(0xFFE65100),
                    secondaryContainer = Color(0xFFFFE0B2),
                    surfaceVariant = Color(0xFFFFF3E0),
                    background = Color(0xFFFAFAFA)
                )
            ) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    MainContainer(
                        onStartVoice = { callback -> startVoiceInput(callback) }
                    )
                }
            }
        }
    }
}

@Composable
fun MainContainer(onStartVoice: (((String) -> Unit) -> Unit)) {
    var showSplash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        delay(2400)
        showSplash = false
    }

    AnimatedVisibility(
        visible = showSplash,
        exit = fadeOut(animationSpec = tween(700)) + slideOutVertically(animationSpec = tween(700)) { -it }
    ) {
        SplashScreen()
    }

    if (!showSplash) {
        AnimatedVisibility(
            visible = !showSplash,
            enter = fadeIn(animationSpec = tween(700)) + slideInVertically(animationSpec = tween(700)) { it }
        ) {
            CookVoiceApp(onStartVoice)
        }
    }
}

@Composable
fun CookVoiceApp(onStartVoice: (((String) -> Unit) -> Unit)) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var currentTab by remember { mutableStateOf(0) }
    var isSpeaking by remember { mutableStateOf(false) }

    val generativeModel = remember {
        GenerativeModel(
            modelName = "gemini-3.5-flash-lite",
            apiKey = "AQ.Ab8RN6Kua5ZEPy1qYjgkegSPsOfs94ZPpbvAHgQUtU9WAavt8A",
            generationConfig = generationConfig {
                maxOutputTokens = 4000
                temperature = 0.7f
            }
        )
    }

    DisposableEffect(Unit) {
        val textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("es", "CO")
            }
        }
        tts = textToSpeech
        onDispose {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
    }

    fun speak(text: String) {
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TTS_ID")
        isSpeaking = true
    }

    fun stopSpeaking() {
        tts?.stop()
        isSpeaking = false
    }

    Scaffold(
        bottomBar = {
            Column {
                AnimatedVisibility(
                    visible = isSpeaking,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut()
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Reproduciendo audio...", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { stopSpeaking() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Detener", fontSize = 12.sp)
                            }
                        }
                    }
                }

                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.RestaurantMenu, contentDescription = "Offline") },
                        label = { Text("Recetario Típico") },
                        selected = currentTab == 0,
                        onClick = { currentTab = 0; stopSpeaking() }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Online") },
                        label = { Text("Chef IA Nariñense") },
                        selected = currentTab == 1,
                        onClick = { currentTab = 1; stopSpeaking() }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues).fillMaxSize()) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(400)) + slideInHorizontally(animationSpec = tween(400)) { if (targetState > initialState) it else -it } togetherWith
                            fadeOut(animationSpec = tween(400)) + slideOutHorizontally(animationSpec = tween(400)) { if (targetState > initialState) -it else it }
                },
                label = "TabTransition"
            ) { tab ->
                if (tab == 0) {
                    OfflineScreen(onPlayVoice = { speak(it) }, onStartVoice = onStartVoice)
                } else {
                    OnlineScreen(generativeModel = generativeModel, onPlayVoice = { speak(it) }, onStartVoice = onStartVoice)
                }
            }
        }
    }
}