package com.example.cookvoice.data

import com.example.cookvoice.R

data class Recipe(
    val name: String,
    val category: String,
    val difficulty: String,
    val prepTime: String,
    val calories: String,
    val ingredients: List<String>,
    val preparation: String,
    val imageRes: Int
)

val narinoRecipes = listOf(
    Recipe(
        name = "Ají de Maní",
        category = "Acompañamiento",
        difficulty = "Fácil",
        prepTime = "15 mins",
        calories = "180 kcal",
        ingredients = listOf("Maní tostado y molido", "Ají al gusto", "Cebolla larga", "Cilantro fresco", "Agua o leche", "Sal"),
        preparation = "1. Licuar o mezclar el maní molido con un poco de agua tibia o leche para formar una pasta suave.\n2. Picar finamente la cebolla larga, el cilantro y el ají.\n3. Incorporar los ingredientes picados a la pasta de maní.\n4. Ajustar de sal y servir fresco para acompañar empanadas o cuy.",
        imageRes = R.drawable.aji_de_mani
    ),
    Recipe(
        name = "Champús Nariñense",
        category = "Bebida Típica",
        difficulty = "Media",
        prepTime = "1 hora",
        calories = "250 kcal",
        ingredients = listOf("Maíz peto cocido", "Lulo picado finamente", "Panela en bloque", "Clavos de olor y canela", "Hojas de naranjo agrio"),
        preparation = "1. Hervir agua con panela, clavos, canela y las hojas de naranjo para hacer un melao aromático.\n2. Licuar una parte del maíz y agregarla al melao para espesar la bebida.\n3. Incorporar el resto del maíz entero y el lulo picado sin licuar.\n4. Revolver, dejar reposar y servir preferiblemente frío.",
        imageRes = R.drawable.champus
    ),
    Recipe(
        name = "Choclo con Queso",
        category = "Entrada / Merienda",
        difficulty = "Fácil",
        prepTime = "25 mins",
        calories = "280 kcal",
        ingredients = listOf("Mazorcas de choclo tierno", "Queso campesino o quesillo fresco", "Agua", "Sal", "Un toque de azúcar (opcional)"),
        preparation = "1. Limpiar las mazorcas retirando las hojas (amero) y los pelos.\n2. Cocinar en abundante agua hirviendo con sal y un toque de azúcar hasta que los granos estén tiernos.\n3. Escurrir bien las mazorcas.\n4. Servir calientes acompañadas de una tajada gruesa de queso campesino fresco.",
        imageRes = R.drawable.choclo_queso
    ),
    Recipe(
        name = "Cucas Pastusas",
        category = "Amasijo / Postre",
        difficulty = "Media",
        prepTime = "45 mins",
        calories = "150 kcal",
        ingredients = listOf("Harina de trigo", "Melao de panela espeso", "Mantequilla", "Polvo para hornear", "Un toque de canela molida"),
        preparation = "1. Mezclar la harina con el polvo de hornear y la canela.\n2. Incorporar el melao de panela y la mantequilla derretida, amasando hasta obtener una masa suave y homogénea.\n3. Formar galletas redondas y planas (cucas) y colocar en una bandeja engrasada.\n4. Hornear a 180°C por 15-20 minutos hasta que doren.",
        imageRes = R.drawable.cucas
    ),
    Recipe(
        name = "Cuchuco con Espinazo",
        category = "Sopa",
        difficulty = "Media",
        prepTime = "1.5 horas",
        calories = "450 kcal",
        ingredients = listOf("Trigo triturado (cuchuco)", "Espinazo de cerdo", "Papa criolla y pastusa", "Arveja y zanahoria", "Ajo y cilantro fresco"),
        preparation = "1. Cocinar el espinazo de cerdo en agua con ajo machacado hasta que ablande.\n2. Agregar el cuchuco previamente lavado y cocinar 40 minutos a fuego medio.\n3. Añadir las papas picadas, arvejas y zanahoria; cocinar hasta que la sopa espese.\n4. Servir muy caliente con cilantro fresco por encima.",
        imageRes = R.drawable.cuchuco_espinazo
    ),
    Recipe(
        name = "Cuy Asado al Carbón",
        category = "Plato Fuerte",
        difficulty = "Difícil",
        prepTime = "2 horas",
        calories = "850 kcal",
        ingredients = listOf("1 cuy entero y limpio", "Ajo machacado", "Comino y sal gruesa", "Achiote para dar color", "Papas criollas de acompañamiento"),
        preparation = "1. Preparar un adobo con ajo, comino y sal. Adobar el cuy por dentro y por fuera; dejar reposar 2 horas o toda la noche.\n2. Insertar en una vara y asar a la brasa a fuego medio por 1.5 horas.\n3. Pincelar constantemente con aceite de achiote para que la piel dore y quede muy crujiente.\n4. Servir entero o en presas con papas y ají de maní.",
        imageRes = R.drawable.cuy_carbon
    ),
    Recipe(
        name = "Dulce de Brevas",
        category = "Postre",
        difficulty = "Fácil",
        prepTime = "45 mins",
        calories = "320 kcal",
        ingredients = listOf("Brebas maduras frescas", "Panela en bloque", "Agua y astillas de canela", "Queso campesino para acompañar"),
        preparation = "1. Hacer un corte en cruz a las brebas y blanquearlas en agua caliente por 5 minutos para quitar amargor.\n2. Preparar un almíbar hirviendo la panela con agua y canela a fuego medio por 15 minutos.\n3. Agregar las brebas y cocinar a fuego lento por 25 minutos hasta que confiten por completo.\n4. Servir tibio o frío acompañado de queso.",
        imageRes = R.drawable.dulce_brevas
    ),
    Recipe(
        name = "Empanadas de Añejo",
        category = "Entrada / Amasijo",
        difficulty = "Media",
        prepTime = "1 hora",
        calories = "350 kcal",
        ingredients = listOf("Masa de añejo (maíz fermentado)", "Arroz blanco cocido", "Carne de res o cerdo picada", "Arveja cocida", "Hogao tradicional"),
        preparation = "1. Preparar el relleno haciendo un sofrito con la carne, el arroz, la arveja y el hogao.\n2. Estirar la masa de añejo muy delgada, colocar una cucharada del relleno y cerrar formando la empanada.\n3. Freír en abundante aceite caliente hasta que estén doradas y crujientes.\n4. Escurrir bien y servir calientes con ají.",
        imageRes = R.drawable.empanadas
    ),
    Recipe(
        name = "Envueltos de Maíz (Chócolo)",
        category = "Amasijo",
        difficulty = "Media",
        prepTime = "1 hora",
        calories = "340 kcal",
        ingredients = listOf("Maíz tierno molido (chócolo)", "Queso campesino rallado", "Panela rallada o azúcar", "Mantequilla derretida", "Hojas frescas de mazorca"),
        preparation = "1. Mezclar el maíz molido con la mantequilla derretida, el queso y la panela hasta tener una masa suave.\n2. Limpiar las hojas de mazorca y colocar una porción de masa en el centro de cada una.\n3. Envolver bien y amarrar con tiras de la misma hoja.\n4. Cocinar al vapor en olla tamalera por 45 minutos.",
        imageRes = R.drawable.envuelto_maiz
    ),
    Recipe(
        name = "Frito Pastuso",
        category = "Plato Fuerte",
        difficulty = "Media",
        prepTime = "45 mins",
        calories = "650 kcal",
        ingredients = listOf("Carne de cerdo (pulpa y un poco de tocino)", "Papas pastusas cocidas", "Maíz tostado", "Ajo, comino y sal"),
        preparation = "1. Marinar la carne de cerdo cortada en trozos con ajo machacado, comino y sal por 30 minutos.\n2. Cocinar las papas pastusas enteras en agua con sal.\n3. Freír la carne en su propia grasa a fuego medio durante 15-20 minutos hasta que esté dorada y crocante.\n4. Servir la carne caliente junto con las papas y el maíz tostado.",
        imageRes = R.drawable.frito_pastuso
    ),
    Recipe(
        name = "Gallina Criolla",
        category = "Plato Fuerte / Sopa",
        difficulty = "Media",
        prepTime = "2.5 horas",
        calories = "700 kcal",
        ingredients = listOf("Gallina criolla en presas", "Papa criolla y pastusa", "Cebolla larga, tomate y ajo", "Yuca y plátano", "Cilantro"),
        preparation = "1. Hacer un hogao con cebolla, tomate y ajo; sofreír las presas de gallina para sellarlas.\n2. Agregar agua y cocinar a presión por 45 minutos o hasta que la carne de la gallina criolla esté blanda.\n3. Añadir la yuca, plátano y papas; cocinar hasta que el caldo espese.\n4. Servir la sopa con la presa y cilantro fresco.",
        imageRes = R.drawable.gallina_criolla
    ),
    Recipe(
        name = "Helado de Paila",
        category = "Postre",
        difficulty = "Media",
        prepTime = "30 mins",
        calories = "210 kcal",
        ingredients = listOf("Jugo concentrado de fruta natural (mora/lulo)", "Hielo picado abundante", "Sal en grano gruesa para congelar"),
        preparation = "1. Colocar una paila de cobre sobre una base de hielo picado mezclado con abundante sal en grano.\n2. Verter el jugo natural en la paila y batir constantemente con cuchara de palo durante 20 minutos.\n3. Raspar las paredes de la paila conforme el jugo se congela hasta lograr una textura cremosa y suave.\n4. Servir de inmediato en conos o copas.",
        imageRes = R.drawable.helado_paila
    ),
    Recipe(
        name = "Hervido Pastuso",
        category = "Bebida Típica Caliente",
        difficulty = "Fácil",
        prepTime = "15 mins",
        calories = "180 kcal",
        ingredients = listOf("Fruta fresca (Mora, maracuyá o lulo)", "Agua", "Panela o azúcar", "Canela en astillas", "Aguardiente blanco"),
        preparation = "1. Hervir el agua con la panela y la canela durante 10 minutos para hacer una infusión.\n2. Agregar el jugo espeso de la fruta elegida y dejar hervir 5 minutos más.\n3. Apagar el fuego y agregar inmediatamente el aguardiente al gusto (con el fuego apagado para que no se evapore el alcohol).\n4. Servir muy caliente en tazas de barro o vidrio.",
        imageRes = R.drawable.hervido
    ),
    Recipe(
        name = "Hornado Pastuso",
        category = "Plato Fuerte",
        difficulty = "Difícil",
        prepTime = "4 horas",
        calories = "900 kcal",
        ingredients = listOf("Pierna de cerdo entera con piel", "Ajo, comino y cerveza para marinar", "Sal gruesa", "Lapingachos y mote para acompañar"),
        preparation = "1. Hacer cortes profundos en la pierna de cerdo y adobar con ajo, comino, cerveza y sal desde la noche anterior.\n2. Hornear a fuego medio por 3 a 4 horas, bañando la carne constantemente con sus propios jugos.\n3. Subir la temperatura del horno al máximo los últimos 20 minutos para que el cuero (piel) quede crujiente y tostado.\n4. Servir en lonjas gruesas con mote y lapingachos.",
        imageRes = R.drawable.hornado_pastuso
    ),
    Recipe(
        name = "Locro de Maíz",
        category = "Sopa",
        difficulty = "Fácil",
        prepTime = "50 mins",
        calories = "410 kcal",
        ingredients = listOf("Maíz peto cocinado", "Papa pastusa en cuadros", "Quesillo campesino desmenuzado", "Sofrito (cebolla, tomate, ajo, achiote)", "Cilantro"),
        preparation = "1. En una olla con caldo, agregar el maíz peto y las papas pastusas; cocinar a fuego medio-alto por 25 minutos.\n2. Aparte, preparar el sofrito con achiote, cebolla, tomate y ajo.\n3. Incorporar el sofrito a la sopa y dejar hervir hasta que la papa se deshaga y espese el caldo de forma natural.\n4. Servir caliente con el quesillo desmenuzado y cilantro por encima.",
        imageRes = R.drawable.locro_maiz
    ),
    Recipe(
        name = "Manjar Blanco",
        category = "Postre",
        difficulty = "Media",
        prepTime = "1.5 horas",
        calories = "380 kcal",
        ingredients = listOf("Leche entera fresca", "Azúcar blanca", "Canela en astillas", "Una pizca de bicarbonato"),
        preparation = "1. Hervir la leche en una olla de fondo grueso (preferiblemente de cobre) junto con la canela y el bicarbonato.\n2. Agregar el azúcar y cocinar a fuego medio-bajo.\n3. Remover constantemente y sin parar con una cuchara de madera (mecer) hasta que la mezcla espese y se vea el fondo de la olla al pasar la cuchara.\n4. Dejar enfriar y servir como postre.",
        imageRes = R.drawable.manjar_blanco
    ),
    Recipe(
        name = "Quimbolitos",
        category = "Amasijo / Postre",
        difficulty = "Media",
        prepTime = "50 mins",
        calories = "280 kcal",
        ingredients = listOf("Harina de maíz", "Mantequilla", "Huevos y Azúcar", "Uvas pasas", "Queso rallado", "Hojas de achira"),
        preparation = "1. Batir enérgicamente la mantequilla con el azúcar hasta cremar, luego agregar los huevos uno a uno.\n2. Incorporar suavemente la harina de maíz tamizada y el queso rallado.\n3. Poner una porción de masa sobre la hoja de achira, decorar con uvas pasas y envolver doblando los bordes.\n4. Cocinar al vapor en olla tamalera por 40-45 minutos.",
        imageRes = R.drawable.quimbolitos
    ),
    Recipe(
        name = "Sopa de Sémola",
        category = "Sopa",
        difficulty = "Fácil",
        prepTime = "35 mins",
        calories = "310 kcal",
        ingredients = listOf("Sémola de trigo", "Caldo rico de res o pollo", "Papas pastusas picadas", "Zanahoria rallada", "Cilantro fresco"),
        preparation = "1. Poner a hervir el caldo de res junto con. la papa picada y la zanahoria rallada hasta que ablanden.\n2. Agregar la sémola en forma de lluvia muy lentamente, revolviendo constantemente con un batidor para evitar que se formen grumos.\n3. Dejar cocinar a fuego medio por 15 minutos hasta que la sopa adquiera una textura suave.\n4. Rectificar la sal y servir bien caliente con cilantro picado.",
        imageRes = R.drawable.sopa_de_semola
    ),
    Recipe(
        name = "Tamal Nariñense",
        category = "Plato Fuerte",
        difficulty = "Difícil",
        prepTime = "2 horas",
        calories = "680 kcal",
        ingredients = listOf("Masa de maíz y arroz molido", "Carnes adobadas (cerdo y pollo)", "Huevo duro y zanahoria", "Guiso o salsa de maní", "Hojas de plátano ahumadas"),
        preparation = "1. Preparar la masa cocinándola ligeramente en caldo para que tome sabor.\n2. Extender una cama de masa sobre la hoja de plátano, colocar trozos de carne, rodajas de huevo, zanahoria y bañar todo con un abundante guiso de maní.\n3. Envolver cuidadosamente formando el tamal y amarrar con pita.\n4. Cocinar al vapor en olla tapada durante hora y media a dos horas.",
        imageRes = R.drawable.tamal
    ),
    Recipe(
        name = "Tortillas de Choclo",
        category = "Amasijo",
        difficulty = "Fácil",
        prepTime = "30 mins",
        calories = "260 kcal",
        ingredients = listOf("Maíz tierno desgranado (choclo)", "Huevo", "Mantequilla", "Sal o azúcar (al gusto)", "Queso fresco rallado"),
        preparation = "1. Moler finamente o licuar los granos de choclo tierno hasta obtener una pasta espesa.\n2. Mezclar la pasta de choclo con el huevo, la mantequilla derretida, el queso rallado y ajustar de sal o azúcar según preferencia.\n3. Calentar una plancha o sartén engrasada y verter cucharones de la mezcla formando tortillas redondas.\n4. Dorar a fuego medio-baixo por ambos lados hasta que estén cocidas por dentro.",
        imageRes = R.drawable.tortillas_choclo
    )
)

fun cleanAiText(text: String): String {
    return text.replace(Regex("[*#_`]+"), "").trim()
}

data class ParsedRecipe(val title: String, val ingredients: String, val preparation: String)

fun parseAiRecipe(rawText: String): ParsedRecipe {
    var title = "Receta Tradicional Nariñense"
    var ingredients = "Ingredientes sugeridos y condimentos tradicionales"
    var preparation = cleanAiText(rawText)

    try {
        val titleMatch = Regex("TÍTULO:\\s*(.*)", RegexOption.IGNORE_CASE).find(rawText)
        if (titleMatch != null) title = cleanAiText(titleMatch.groupValues[1])

        val ingMatch = Regex("INGREDIENTES:\\s*(.*?)(PREPARACIÓN:|$)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(rawText)
        if (ingMatch != null) ingredients = cleanAiText(ingMatch.groupValues[1])

        val prepMatch = Regex("PREPARACIÓN:\\s*(.*)", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(rawText)
        if (prepMatch != null) preparation = cleanAiText(prepMatch.groupValues[1])

        if (ingMatch == null && prepMatch == null) {
            val lines = rawText.lines().map { cleanAiText(it) }.filter { it.isNotEmpty() }
            if (lines.isNotEmpty()) {
                title = lines[0].take(50)
                preparation = lines.drop(1).joinToString("\n")
                ingredients = "Ingredientes y condimentos detallados en la preparación."
            }
        }
    } catch (e: Exception) {
        preparation = cleanAiText(rawText)
    }

    return ParsedRecipe(title, ingredients, preparation)
}